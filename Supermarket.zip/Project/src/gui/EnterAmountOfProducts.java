package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.AbstractTableModel;

import dao.DaoFactory;
import dao.ProductAmountPurchaseDao;
import entity.Product;
import entity.ProductAmountPurchase;
import entity.Purchase;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;

public class EnterAmountOfProducts extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField amount_textField;
	private Product product;
	private Purchase purchase;
	private JLabel enter_amount_label;
	private DaoFactory factory;
	private AbstractTableModel model;
	/**
	 * Launch the application.
	 */
	// public static void main(String[] args) {
	// try {
	// EnterAmountOfProducts dialog = new EnterAmountOfProducts();
	// dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
	// dialog.setVisible(true);
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }

	/**
	 * Create the dialog.
	 */
	public EnterAmountOfProducts(Product product, Purchase purchase, AbstractTableModel model) {
		this.product = product;
		this.purchase = purchase;
		this.model = model;

		setTitle("Amount of products");
		setResizable(false);
		setBounds(100, 100, 370, 195);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(null);
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel panel = new JPanel();
			FlowLayout flowLayout = (FlowLayout) panel.getLayout();
			flowLayout.setVgap(15);
			contentPanel.add(panel);
			panel.setBackground(new Color(255, 250, 240));
			{
				enter_amount_label = new JLabel("Enter amount of products");
				enter_amount_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
				panel.add(enter_amount_label);
			}
			{
				amount_textField = new JTextField();
				enter_amount_label.setLabelFor(amount_textField);
				amount_textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
				amount_textField.setColumns(20);
				panel.add(amount_textField);
			}
		}
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel, BorderLayout.SOUTH);
			panel.setBackground(new Color(255, 228, 196));
			{
				JButton ok_button = new JButton("ok");
				ok_button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						createAmount();
						close();
					}
				});
				ok_button.setForeground(Color.WHITE);
				ok_button.setFont(new Font("Tahoma", Font.PLAIN, 17));
				ok_button.setBackground(Color.RED);
				panel.add(ok_button);
			}
		}
	}

	public void createAmount() {
		if (!amount_textField.getText().trim().equals("")) {
			factory = new DaoFactory();
			ProductAmountPurchase amount = new ProductAmountPurchase(Double.parseDouble(amount_textField.getText()),
					purchase, product);
			model.fireTableDataChanged();

		} else
			JOptionPane.showMessageDialog(contentPanel, "Field is empty", "Error", JOptionPane.ERROR_MESSAGE);

	}
	public void close() {
		WindowEvent winClose = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClose);
	}

}
