package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.LabelUI;
import javax.swing.table.AbstractTableModel;

import entity.ProductAmountPurchase;
import entity.Purchase;

import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.TextArea;
import java.awt.Toolkit;
import java.awt.Label;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Cursor;
import java.awt.Panel;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;

public class DeletePurchaseDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private Purchase purchase ;
	private AbstractTableModel model;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		try {
//			DeletePurchaseDialog dialog = new DeletePurchaseDialog();
//			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
//			dialog.setVisible(true);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	/**
	 * Create the dialog.
	 */
	
	public DeletePurchaseDialog(Purchase purchase, AbstractTableModel model) {
		this.purchase = purchase;
		this.model = model;
		setFont(new Font("Dialog", Font.PLAIN, 17));
		setTitle("Delete purchase");
		setResizable(false);
		setBounds(100, 100, 370, 195);	
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 250, 240));
		contentPanel.setBorder(null);
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel main_panel = new JPanel();
			main_panel.setBackground(new Color(255, 250, 240));
			FlowLayout fl_main_panel = (FlowLayout) main_panel.getLayout();
			fl_main_panel.setVgap(15);
			fl_main_panel.setHgap(0);
			contentPanel.add(main_panel, BorderLayout.CENTER);
			{
				JLabel first_label = new JLabel("Do you want to delete ");
				first_label.setHorizontalTextPosition(SwingConstants.CENTER);
				first_label.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
				first_label.setAlignmentY(Component.TOP_ALIGNMENT);
				first_label.setAlignmentX(Component.RIGHT_ALIGNMENT);
				first_label.setHorizontalAlignment(SwingConstants.CENTER);
				first_label.setFont(new Font("Dialog", Font.PLAIN, 17));		
				main_panel.add(first_label);
			}
			{
				Label second_label = new Label("all products from this purchase?");
				second_label.setFont(new Font("Dialog", Font.PLAIN, 17));
				second_label.setAlignment(Label.CENTER);
				main_panel.add(second_label);
			}
		}
		{
			JPanel button_panel = new JPanel();
			button_panel.setBackground(new Color(255, 228, 196));
			contentPanel.add(button_panel, BorderLayout.SOUTH);
			FlowLayout fl_button_panel = new FlowLayout(FlowLayout.CENTER);
			fl_button_panel.setHgap(50);
			button_panel.setLayout(fl_button_panel);
			{
				JButton ok_button = new JButton("Yes");
				ok_button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						deleteAllProductItems();
						close();
					}
				});
				ok_button.setForeground(new Color(255, 255, 255));
				ok_button.setBackground(new Color(255, 0, 0));
				ok_button.setFont(new Font("Tahoma", Font.PLAIN, 17));
				ok_button.setActionCommand("OK");
				button_panel.add(ok_button);
				getRootPane().setDefaultButton(ok_button);
			}
			{
				JButton cancel_button = new JButton("No");
				cancel_button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						close();
					}
				});
				cancel_button.setBackground(new Color(255, 0, 0));
				cancel_button.setForeground(new Color(255, 255, 255));
				cancel_button.setFont(new Font("Tahoma", Font.PLAIN, 17));
				cancel_button.setActionCommand("Cancel");
				button_panel.add(cancel_button);
			}
		}
	}
	public void deleteAllProductItems() {
		for (ProductAmountPurchase p : purchase.getProductAmounts()) {
			purchase.removeProductAmount(p);
			model.fireTableDataChanged();
		}
	}
	public void close() {
		WindowEvent winClose = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClose);
	}

}
