package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.CardDao;
import dao.ClientDao;
import dao.DaoFactory;
import entity.Card;
import entity.Client;
import entity.DiscountCard;
import entity.Purchase;
import entity.SavingCard;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;

public class ScanCardDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField card_number_textField;
	private JLabel card_number_label;
	private Purchase purchase;
	private DaoFactory factory;

	/**
	 * Launch the application.
	 */
	// public static void main(String[] args) {
	// try {
	// ScanCardDialog dialog = new ScanCardDialog();
	// dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
	// dialog.setVisible(true);
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }

	/**
	 * Create the dialog.
	 */
	public ScanCardDialog(Purchase purchase) {

		this.purchase = purchase;

		setResizable(false);
		setFont(new Font("Dialog", Font.PLAIN, 17));
		setTitle("Scan card");
		setBounds(100, 100, 370, 195);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(null);
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel main_panel = new JPanel();
			main_panel.setBackground(new Color(255, 250, 240));
			FlowLayout fl_main_panel = (FlowLayout) main_panel.getLayout();
			fl_main_panel.setVgap(15);
			contentPanel.add(main_panel, BorderLayout.CENTER);
			{
				card_number_label = new JLabel("Enter card number");
				card_number_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
				main_panel.add(card_number_label);
			}
			{
				card_number_textField = new JTextField();
				card_number_label.setLabelFor(card_number_textField);
				card_number_textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
				main_panel.add(card_number_textField);
				card_number_textField.setColumns(20);
			}
		}
		{
			JPanel button_panel = new JPanel();
			button_panel.setBackground(new Color(255, 228, 196));
			contentPanel.add(button_panel, BorderLayout.SOUTH);
			{
				JButton ok_button = new JButton("ok");
				ok_button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						scanCard();
					}
				});
				ok_button.setForeground(new Color(255, 255, 255));
				ok_button.setBackground(new Color(255, 0, 0));
				ok_button.setFont(new Font("Tahoma", Font.PLAIN, 17));
				button_panel.add(ok_button);
			}
		}
	}

	public void scanCard() {
		if (!card_number_textField.getText().trim().equals("")) {
			factory = new DaoFactory();

			ClientDao clientDao = (ClientDao) factory.getDAO(Integer.class, Client.class);
			Client client = clientDao.findClientByCard(Long.parseLong(card_number_textField.getText()));
			if (client == null) {
				JOptionPane.showMessageDialog(contentPanel, "Client with this card is not found", "Error",
						JOptionPane.ERROR_MESSAGE);

			} else {
				if (client.getSavingCard() != null) {
					System.out.println("saving: " + client.getSavingCard());

				}
				if (client.getDiscountCard() != null) {
					System.out.println("discount: " + client.getDiscountCard());
				}
				purchase.setClient(client);
				close();

			}

		} else {
			JOptionPane.showMessageDialog(contentPanel, "Empty field", "Error", JOptionPane.ERROR_MESSAGE);
		}

	}

	public void close() {
		WindowEvent winClose = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClose);
	}

}
