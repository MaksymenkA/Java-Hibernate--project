package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;

import dao.DaoFactory;
import dao.EmployeeDao;
import entity.Client;
import entity.Employee;
import entity.ProductAmountPurchase;
import entity.Purchase;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.FlowLayout;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.GridLayout;
import javax.swing.JTable;
import java.awt.Panel;
import java.awt.Button;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Dialog.ModalExclusionType;
import javax.swing.JScrollPane;

public class ScanProductForm extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private Purchase purchase;
	private Client client;
	private DaoFactory factory;
	private JLabel total_sum_label; 

	private MyTableModel model;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ScanProductForm frame = new ScanProductForm();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ScanProductForm() {
		init();

		setFont(new Font("Dialog", Font.BOLD, 17));
		setTitle("Cashier desk");
		setForeground(new Color(176, 224, 230));
		setBackground(new Color(176, 224, 230));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 400, 903, 526);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 240));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JPanel menu_bar_panel = new JPanel();
		menu_bar_panel.setBackground(new Color(255, 228, 181));
		contentPane.add(menu_bar_panel, BorderLayout.NORTH);
		menu_bar_panel.setLayout(new BorderLayout(0, 0));

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBorderPainted(false);
		menuBar.setBackground(new Color(255, 228, 181));
		menu_bar_panel.add(menuBar, BorderLayout.CENTER);

		JMenu card_menu = new JMenu("Card");
		card_menu.setFont(new Font("Segoe UI", Font.PLAIN, 17));
		card_menu.setBackground(new Color(255, 228, 181));
		menuBar.add(card_menu);

		JMenuItem create_card_item = new JMenuItem("Create");
		create_card_item.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ChooseTypeOfCardDialog card_type = new ChooseTypeOfCardDialog();
				card_type.setLocationRelativeTo(null);
				card_type.setVisible(true);
			}
		});
		create_card_item.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		create_card_item.setBackground(new Color(255, 228, 181));
		card_menu.add(create_card_item);

		JMenuItem scan_card_item = new JMenuItem("Scan");
		scan_card_item.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ScanCardDialog scan_card = new ScanCardDialog(purchase);
				scan_card.setLocationRelativeTo(null);
				scan_card.setVisible(true);
			}
		});
		scan_card_item.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		scan_card_item.setBackground(new Color(255, 228, 181));
		card_menu.add(scan_card_item);

		JMenu purchase_menu = new JMenu("Purchase");
		purchase_menu.setFont(new Font("Segoe UI", Font.PLAIN, 17));
		purchase_menu.setBackground(new Color(255, 228, 181));
		menuBar.add(purchase_menu);

		JMenuItem delete_item = new JMenuItem("Delete");
		delete_item.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeletePurchaseDialog delete_purchase = new DeletePurchaseDialog(purchase,model);
				delete_purchase.setLocationRelativeTo(null);
				delete_purchase.setVisible(true);
			}
		});
		delete_item.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		delete_item.setBackground(new Color(255, 228, 181));
		purchase_menu.add(delete_item);

		Panel button_panel = new Panel();
		button_panel.setBackground(new Color(255, 228, 196));
		contentPane.add(button_panel, BorderLayout.SOUTH);
		button_panel.setLayout(new BorderLayout(0, 0));

		Button payment_button = new Button("  Payment  ");
		payment_button.setForeground(new Color(255, 255, 255));
		payment_button.setFont(new Font("Dialog", Font.PLAIN, 17));
		payment_button.setBackground(new Color(255, 0, 0));
		button_panel.add(payment_button, BorderLayout.EAST);
		payment_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PaymentDialog payment = new PaymentDialog(purchase,model);
				payment.setLocationRelativeTo(null);
				payment.setVisible(true);
				;
			}
		});

		Button enter_bar_code_manually = new Button("Enter bar code");
		enter_bar_code_manually.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EnterBarCodeDialog bar_code = new EnterBarCodeDialog(purchase, model);
				bar_code.setLocationRelativeTo(null);
				bar_code.setVisible(true);
			}
		});
		enter_bar_code_manually.setForeground(new Color(255, 255, 255));
		enter_bar_code_manually.setBackground(new Color(255, 0, 0));
		enter_bar_code_manually.setFont(new Font("Tahoma", Font.PLAIN, 17));
		button_panel.add(enter_bar_code_manually, BorderLayout.WEST);

		JPanel table_panel = new JPanel();
		
		JScrollPane scrollPane = new JScrollPane();

		table_panel.setBackground(new Color(255, 250, 240));
		table_panel.setLayout(new BorderLayout(0, 0));

		table = new JTable();
		
		table.setBackground(new Color(255, 250, 240));
		table_panel.add(table);
		model = new MyTableModel();
		table.setModel(model);
		
		scrollPane.setViewportView(table);
		table_panel.add(scrollPane, BorderLayout.CENTER);
		contentPane.add(table_panel);
		
	
		Action delete = new AbstractAction()
		{
		    public void actionPerformed(ActionEvent e)
		    {
		        JTable table = (JTable)e.getSource();
		        int modelRow = Integer.valueOf( e.getActionCommand() );
		        ((DefaultTableModel)table.getModel()).removeRow(modelRow);
//		        if(e.getSource().equals(delete))
//		         {
//		                 if(table.getSelectedRow()<0)
//		                 {
//		         			JOptionPane.showMessageDialog(t, "Date is wrong", "Error", JOptionPane.ERROR_MESSAGE);
//
//		                 }
//		                 else
//		                 {
//		                     mtb.removeRow(table.getSelectedRow()); 
//
//		                 }
//		         }       
		         }
		    
		};
		ButtonColumn buttonColumn = new ButtonColumn(table, delete, 5);
		model.fireTableDataChanged();
		buttonColumn.setMnemonic(KeyEvent.VK_D);
		
		

		Panel label_panel = new Panel();
		label_panel.setBackground(new Color(255, 235, 205));
		table_panel.add(label_panel, BorderLayout.SOUTH);
		label_panel.setLayout(new FlowLayout(FlowLayout.RIGHT, 5, 5));

		JLabel label = new JLabel("Total sum:");
		label.setBackground(new Color(255, 235, 205));
		label.setFont(new Font("Tahoma", Font.PLAIN, 17));
		label_panel.add(label);

		total_sum_label = new JLabel("Totl");
		total_sum_label.setBackground(new Color(255, 235, 205));
		total_sum_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
		label_panel.add(total_sum_label);
		
		
		
		/// Generated code

	}

	private void init() {
		factory = new DaoFactory();
		EmployeeDao emDao = (EmployeeDao) factory.getDAO(Integer.class, Employee.class);
		Employee cashier = emDao.findById(1);
		purchase = new Purchase(LocalDate.now(), cashier);
		System.out.println(cashier.getId());
	}

	private class MyTableModel extends AbstractTableModel{
		private List<ProductAmountPurchase> tempProductsAmounts; 
		
		
		
		@Override
		public int getRowCount() {
			tempProductsAmounts = new ArrayList<>(purchase.getProductAmounts());
			double sum = 0.0;
			for (ProductAmountPurchase productAmountPurchase : tempProductsAmounts) {
				 sum += productAmountPurchase.getProduct().getPrice() * productAmountPurchase.getAmount();
								
			}
			total_sum_label.setText(String.valueOf(sum));	
			return tempProductsAmounts.size();
		}

		public void removeRow(int row) {
		    fireTableRowsDeleted(row, row);
			
		}

		@Override
		public int getColumnCount() {
			return 6;
		}
		
		@Override
		public Object getValueAt(int rowIndex, int columnIndex) {
			
			switch (columnIndex) {
			case 0:
				return tempProductsAmounts.get(rowIndex).getProduct().getName() ;
			case 1:
				return tempProductsAmounts.get(rowIndex).getProduct().getBrand();
			case 2:
				return tempProductsAmounts.get(rowIndex).getProduct().getPrice();
			case 3:
				return tempProductsAmounts.get(rowIndex).getAmount();
			case 4:{
				double sum =tempProductsAmounts.get(rowIndex).getProduct().getPrice()* tempProductsAmounts.get(rowIndex).getAmount();
				return sum;
			}
			case 5: 
				return "Delete" ;
				
			default:
				return null;
			}
		}
		@Override
		public Class<?> getColumnClass(int i) {
			switch (i) {
			case 0:
				return String.class;
			case 1:
				return String.class;
			case 2:
				return Double.class;
			case 3:
				return Double.class;
			case 4:
				return Double.class;
			case 5:
				return String.class;

			default:
				return null;
			}
		}

		@Override
		public String getColumnName(int i) {
			switch (i) {
			case 0:
				return "Product name";
			case 1:
				return "Brand";
			case 2:
				return "Price";
			case 3:
				return "Amount";
			case 4:
				return "Sum";
			case 5: 
				return "Delete";
			default:
				return null;
			}
		}
	}
	public void close() {
		WindowEvent winClose = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClose);
	}
	


   

}
