package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.ClientDao;
import dao.Dao;
import dao.DaoFactory;
import entity.CardType;
import entity.Client;
import entity.DiscountCard;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.awt.event.ActionEvent;

import javax.persistence.EntityManager;
import javax.swing.DefaultComboBoxModel;

public class CreateDiscountCardDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField name_textField;
	private JTextField surname_textField;
	private JTextField phone_number_textField;
	private JTextField discount_percentage_textField;
	private JLabel name_label;
	private JLabel surname_label;
	private JLabel phone_number_label;
	private JLabel discount_percentage_label;
	private JLabel expire_date_label;
	private JTextField expire_date_textField;
	private JLabel type_label;
	private JComboBox comboBox;
	private JLabel brand_label;
	private JTextField brand_textField;
	private JLabel card_name_label;
	private JTextField card_name_textField;

	// /**
	// * Launch the application.
	// */
	// public static void main(String[] args) {
	// try {
	// CreateDiscountCardDialog dialog = new CreateDiscountCardDialog();
	// dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
	// dialog.setVisible(true);
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }

	/**
	 * Create the dialog.
	 */
	public CreateDiscountCardDialog() {
		setResizable(false);
		setFont(new Font("Dialog", Font.PLAIN, 17));
		setTitle("Discount card");
		setBounds(100, 100, 440, 460);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 250, 240));
		contentPanel.setBorder(null);
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel button_panel = new JPanel();
			button_panel.setBackground(new Color(255, 228, 196));
			contentPanel.add(button_panel, BorderLayout.SOUTH);
			button_panel.setLayout(new FlowLayout(FlowLayout.RIGHT, 5, 5));
			{
				JButton create_button = new JButton("Create");
				create_button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						createDiscountCard();
						close();
					}
				});
				create_button.setForeground(new Color(255, 255, 255));
				create_button.setFont(new Font("Tahoma", Font.PLAIN, 17));
				create_button.setBackground(new Color(255, 0, 0));
				button_panel.add(create_button);
			}
		}
		{
			JPanel main_panel = new JPanel();
			main_panel.setBorder(null);
			FlowLayout fl_main_panel = (FlowLayout) main_panel.getLayout();
			fl_main_panel.setVgap(0);
			contentPanel.add(main_panel, BorderLayout.CENTER);
			main_panel.setBackground(new Color(255, 250, 240));
			{
				JPanel central_panel = new JPanel();
				central_panel.setBackground(new Color(255, 250, 240));
				main_panel.add(central_panel);
				central_panel.setLayout(new GridLayout(8, 2, 0, 20));
				{
					name_label = new JLabel("Name\r\n");
					name_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
					central_panel.add(name_label);
				}
				{
					name_textField = new JTextField();
					name_label.setLabelFor(name_textField);
					name_textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
					name_textField.setColumns(12);
					central_panel.add(name_textField);
				}
				{
					surname_label = new JLabel("Surname");
					surname_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
					central_panel.add(surname_label);
				}
				{
					surname_textField = new JTextField();
					surname_label.setLabelFor(surname_textField);
					surname_textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
					surname_textField.setColumns(12);
					central_panel.add(surname_textField);
				}
				{
					phone_number_label = new JLabel("Phone number");
					phone_number_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
					central_panel.add(phone_number_label);
				}
				{
					phone_number_textField = new JTextField();
					phone_number_label.setLabelFor(phone_number_textField);
					phone_number_textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
					phone_number_textField.setColumns(12);
					central_panel.add(phone_number_textField);
				}
				{
					discount_percentage_label = new JLabel("Discount percentage");
					discount_percentage_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
					central_panel.add(discount_percentage_label);
				}
				{
					discount_percentage_textField = new JTextField();
					discount_percentage_label.setLabelFor(discount_percentage_textField);
					discount_percentage_textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
					discount_percentage_textField.setColumns(12);
					central_panel.add(discount_percentage_textField);
				}
				{
					type_label = new JLabel("Type");
					type_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
					central_panel.add(type_label);
				}
				{
					comboBox = new JComboBox();
					comboBox.setModel(
							new DefaultComboBoxModel(new String[] { "Platinum", "Gold", "Silver", "Bronse" }));
					comboBox.setFont(new Font("Tahoma", Font.PLAIN, 17));
					type_label.setLabelFor(comboBox);
					central_panel.add(comboBox);
				}
				{
					expire_date_label = new JLabel("Expire date");
					expire_date_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
					central_panel.add(expire_date_label);
				}
				{
					expire_date_textField = new JTextField();
					expire_date_textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
					expire_date_label.setLabelFor(expire_date_textField);
					central_panel.add(expire_date_textField);
					expire_date_textField.setColumns(10);
				}
				{
					brand_label = new JLabel("Brand");
					brand_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
					central_panel.add(brand_label);
				}
				{
					brand_textField = new JTextField();
					brand_textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
					brand_label.setLabelFor(brand_textField);
					central_panel.add(brand_textField);
					brand_textField.setColumns(10);
				}
				{
					card_name_label = new JLabel("Card name");
					card_name_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
					central_panel.add(card_name_label);
				}
				{
					card_name_textField = new JTextField();
					card_name_textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
					card_name_label.setLabelFor(card_name_textField);
					central_panel.add(card_name_textField);
					card_name_textField.setColumns(10);
				}
			}
		}
	}

	public void createDiscountCard() {
		try {
			Client client = new Client(name_textField.getText(), surname_textField.getText(),
					phone_number_textField.getText(), CardType.DISCOUNTCARD, comboBox.getSelectedItem().toString(),
					LocalDate.parse(expire_date_textField.getText()), brand_textField.getText(),
					card_name_textField.getText(), Integer.parseInt(discount_percentage_textField.getText()), 0.0);
			DaoFactory factory = new DaoFactory();
			ClientDao clientDao = (ClientDao) factory.getDAO(Integer.class, Client.class);
			clientDao.create(client);

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(contentPanel, "Data is wrong", "Error", JOptionPane.ERROR_MESSAGE);

		}
	}
	public void close() {
		WindowEvent winClose = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClose);
	}
}
