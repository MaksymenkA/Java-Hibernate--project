package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;

public class ChooseTypeOfCardDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		try {
//			ChooseTypeOfCardDialog dialog = new ChooseTypeOfCardDialog();
//			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
//			dialog.setVisible(true);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	/**
	 * Create the dialog.
	 */
	public ChooseTypeOfCardDialog() {
		setResizable(false);
		setFont(new Font("Dialog", Font.PLAIN, 17));
		setTitle("Choose type of card");
		setBounds(100, 100, 370, 195);	
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 250, 240));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel discount_card_panel = new JPanel();
			discount_card_panel.setBackground(new Color(255, 250, 240));
			FlowLayout fl_discount_card_panel = (FlowLayout) discount_card_panel.getLayout();
			fl_discount_card_panel.setVgap(20);
			contentPanel.add(discount_card_panel, BorderLayout.NORTH);
			
			{
				JButton discount_card_button = new JButton("Discount card");
				discount_card_button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						openDiscountCardWindow();
						close();
					}
				});
				discount_card_button.setForeground(new Color(255, 255, 255));
				discount_card_button.setBackground(new Color(255, 0, 0));
				discount_card_button.setFont(new Font("Tahoma", Font.PLAIN, 17));
				discount_card_panel.add(discount_card_button);
			}
		}
		{
			JPanel saving_card_panel = new JPanel();
			saving_card_panel.setBackground(new Color(255, 250, 240));
			FlowLayout fl_saving_card_panel = (FlowLayout) saving_card_panel.getLayout();
			fl_saving_card_panel.setVgap(25);
			contentPanel.add(saving_card_panel, BorderLayout.SOUTH);
			{
				JButton saving_card_button = new JButton("  Saving card\r\n ");
				saving_card_button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						openSavingCardWindow();
						close();
					}
				});
				saving_card_button.setForeground(new Color(255, 255, 255));
				saving_card_button.setBackground(new Color(255, 0, 0));
				saving_card_button.setFont(new Font("Tahoma", Font.PLAIN, 17));
				saving_card_panel.add(saving_card_button);

			}
		}
	}
	public void openDiscountCardWindow() {
		CreateDiscountCardDialog discount = new CreateDiscountCardDialog();
		discount.setLocationRelativeTo(null);
		discount.setVisible(true);
	}
	public void openSavingCardWindow() {
		CreateSavingCardDialog saving = new CreateSavingCardDialog();
		saving.setLocationRelativeTo(null);
		saving.setVisible(true);

	}
	public void close() {
		WindowEvent winClose = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClose);
	}

}
