package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.AbstractTableModel;

import dao.DaoFactory;
import dao.PurchaseDao;
import entity.Client;
import entity.ProductAmountPurchase;
import entity.Purchase;

import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Dialog.ModalityType;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;

public class PaymentDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField total_sum_textField;
	private JTextField entered_sum_textField;
	private JLabel total_sum_label;
	private JLabel entered_sum_label;
	private Purchase purchase;
	private List<ProductAmountPurchase> tempProductsAmounts; 
	private AbstractTableModel model;


	/**
	 * Launch the application.
	 */
	// public static void main(String[] args) {
	// try {
	// PaymentDialog dialog = new PaymentDialog();
	// dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
	// dialog.setVisible(true);
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }

	/**
	 * Create the dialog.
	 */
	public PaymentDialog(Purchase purchase, AbstractTableModel model) {
		this.purchase = purchase;
		this.model = model;
		setModalityType(ModalityType.APPLICATION_MODAL);
		setResizable(false);
		setFont(new Font("Dialog", Font.PLAIN, 17));
		setTitle("Payment");
		setBounds(100, 100, 370, 195);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 250, 240));
		contentPanel.setBorder(null);
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel main_panel = new JPanel();
			main_panel.setBackground(new Color(255, 250, 240));
			FlowLayout flowLayout = (FlowLayout) main_panel.getLayout();
			flowLayout.setVgap(15);
			contentPanel.add(main_panel, BorderLayout.NORTH);
			{
				JPanel central_panel = new JPanel();
				central_panel.setBackground(new Color(255, 250, 240));
				main_panel.add(central_panel);
				central_panel.setLayout(new GridLayout(2, 2, 10, 20));
				{
					total_sum_label = new JLabel("Total sum");
					total_sum_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
					central_panel.add(total_sum_label);
				}
				{
					total_sum_textField = new JTextField();					
					total_sum_label.setLabelFor(total_sum_textField);
					total_sum_textField.setBackground(new Color(255, 255, 255));
					total_sum_textField.setEditable(false);
					total_sum_textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
					central_panel.add(total_sum_textField);
					total_sum_textField.setColumns(10);
					makeTotalSum();
				}
					
				{
					entered_sum_label = new JLabel("Entered sum");
					entered_sum_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
					central_panel.add(entered_sum_label);
				}
				{
					entered_sum_textField = new JTextField();
					entered_sum_label.setLabelFor(entered_sum_textField);
					entered_sum_textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
					central_panel.add(entered_sum_textField);
					entered_sum_textField.setColumns(10);
				}
			}
		}
		{
			JPanel panel1 = new JPanel();
			panel1.setBackground(new Color(255, 228, 196));
			contentPanel.add(panel1, BorderLayout.SOUTH);
			{
				JButton btnNewButton = new JButton("Pay");
				btnNewButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						checkEnteredSum();
					}
				});
				btnNewButton.setForeground(new Color(255, 255, 255));
				btnNewButton.setBackground(new Color(255, 0, 0));
				btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 17));
				panel1.add(btnNewButton);
			}
		}
	}

	public void close() {
		WindowEvent winClose = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClose);
	}
	
	public void makeTotalSum() {
		Client client = purchase.getClient();
		
		tempProductsAmounts = new ArrayList<>(purchase.getProductAmounts());
		double sum = 0.0;
		for (ProductAmountPurchase productAmountPurchase : tempProductsAmounts) {
			 sum += productAmountPurchase.getProduct().getPrice() * productAmountPurchase.getAmount();
		}
		 if(client.getSavingCard() != null) {
			 client.getSavingCard().setAmountOfMoney(0.5); 
			
		}else if(client.getDiscountCard() != null) {
			double disount =client.getDiscountCard().getDiscountPercentage();
			sum -= (disount/100.0)*sum;
		}
	
		total_sum_textField.setText(String.valueOf(sum));					

		}
	public void checkEnteredSum() {
		if(Double.parseDouble(entered_sum_textField.getText()) == Double.parseDouble(total_sum_textField.getText())) {
			JOptionPane.showMessageDialog(contentPanel, "Payment is passed", "Message", JOptionPane.OK_OPTION);
			addPurchaseToTheDatabase();
			close();
		}else if(Double.parseDouble(entered_sum_textField.getText()) > Double.parseDouble(total_sum_textField.getText())) {
			double difference = Double.parseDouble(entered_sum_textField.getText()) -Double.parseDouble(total_sum_textField.getText());
			ChangeDialog change = new ChangeDialog(difference,purchase,model);
			change.setLocationRelativeTo(null);
			change.setVisible(true);
			close();
		}else if(Double.parseDouble(entered_sum_textField.getText()) < Double.parseDouble(total_sum_textField.getText())) {
			JOptionPane.showMessageDialog(contentPanel, "The entered sum is smaller than total", "Error", JOptionPane.ERROR_MESSAGE);

		}else if(entered_sum_textField.getText().equals("")) {
			JOptionPane.showMessageDialog(contentPanel, "The field is empty", "Error", JOptionPane.ERROR_MESSAGE);

		}
		
	}
	public void addPurchaseToTheDatabase() {
		try {

			
			DaoFactory factory = new DaoFactory();
			PurchaseDao dao = (PurchaseDao) factory.getDAO(Long.class, Purchase.class);			
			dao.create(purchase);
			deleteAllProductItems();

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(contentPanel, "Date is wrong", "Error", JOptionPane.ERROR_MESSAGE);

		}
	}
	public void deleteAllProductItems() {
		for (ProductAmountPurchase p : purchase.getProductAmounts()) {
			purchase.removeProductAmount(p);
			model.fireTableDataChanged();
		}
	}
	

}
