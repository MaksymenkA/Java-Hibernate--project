package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.AbstractTableModel;

import dao.ClientDao;
import dao.DaoFactory;
import dao.PurchaseDao;
import entity.CardType;
import entity.Client;
import entity.ProductAmountPurchase;
import entity.Purchase;

import java.awt.Dialog.ModalityType;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.time.LocalDate;
import java.awt.event.ActionEvent;

public class ChangeDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField change_text_field;
	private JLabel change_label;
	private double difference;
	private Purchase purchase;
	private AbstractTableModel model;
	
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		try {
//			ChangeDialog dialog = new ChangeDialog();
//			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
//			dialog.setVisible(true);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	/**
	 * Create the dialog.
	 */
	public ChangeDialog(double difference,Purchase purchase, AbstractTableModel model) {
		this.difference = difference;
		this.purchase = purchase;
		this.model = model;
		setModalityType(ModalityType.APPLICATION_MODAL);
		setResizable(false);
		setForeground(new Color(0, 0, 0));
		setBackground(new Color(255, 192, 203));
		setBounds(100, 100, 370, 195);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 250, 240));
		contentPanel.setBorder(null);
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel central_panel = new JPanel();
			FlowLayout fl_central_panel = (FlowLayout) central_panel.getLayout();
			fl_central_panel.setAlignment(FlowLayout.LEADING);
			fl_central_panel.setHgap(30);
			fl_central_panel.setVgap(50);
			central_panel.setBackground(new Color(255, 250, 250));
			contentPanel.add(central_panel, BorderLayout.CENTER);
			{
				change_label = new JLabel("Change");
				central_panel.add(change_label);
				change_label.setHorizontalAlignment(SwingConstants.CENTER);
				change_label.setFont(new Font("Tahoma", Font.PLAIN, 17));
			}
			{
				change_text_field = new JTextField();
				change_label.setLabelFor(change_text_field);
				change_text_field.setEditable(false);
				central_panel.add(change_text_field);
				change_text_field.setHorizontalAlignment(SwingConstants.LEFT);
				change_text_field.setFont(new Font("Tahoma", Font.PLAIN, 17));
				change_text_field.setColumns(15);
				change_text_field.setText(String.valueOf(difference));
			}
		}
		{
			JPanel button_panel = new JPanel();
			button_panel.setBackground(new Color(255, 228, 196));
			contentPanel.add(button_panel, BorderLayout.SOUTH);
			{
				JButton ok_button = new JButton("ok");
				ok_button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						addPurchaseToTheDatabase();
						close();
					}
				});
				ok_button.setForeground(new Color(255, 255, 255));
				ok_button.setFont(new Font("Tahoma", Font.PLAIN, 17));
				ok_button.setBackground(new Color(255, 0, 0));
				button_panel.add(ok_button);
			}
		}
	}
	public void close() {
		WindowEvent winClose = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClose);
	}
	public void addPurchaseToTheDatabase() {
		try {

			
			DaoFactory factory = new DaoFactory();
			PurchaseDao dao = (PurchaseDao) factory.getDAO(Long.class, Purchase.class);
			dao.create(purchase);
			deleteAllProductItems();
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(contentPanel, "Date is wrong", "Error", JOptionPane.ERROR_MESSAGE);

		}
	}
	public void deleteAllProductItems() {
		for (ProductAmountPurchase p : purchase.getProductAmounts()) {
			purchase.removeProductAmount(p);
			model.fireTableDataChanged();
		}
	}

}
