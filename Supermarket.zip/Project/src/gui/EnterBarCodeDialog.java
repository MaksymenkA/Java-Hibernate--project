package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.AbstractTableModel;

import dao.DaoFactory;
import dao.ProductDao;
import entity.Product;
import entity.Purchase;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;

public class EnterBarCodeDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private DaoFactory factory;
	private Purchase purchase;
	private AbstractTableModel model;

	/**
	 * Launch the application.
	 */
	// public static void main(String[] args) {
	// try {
	// EnterBarCodeDialog dialog = new EnterBarCodeDialog();
	// dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
	// dialog.setVisible(true);
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }

	/**
	 * Create the dialog.
	 */
	public EnterBarCodeDialog(Purchase purchase,AbstractTableModel model) {
		this.purchase = purchase;
		this.model = model;

		
		setTitle("Scan product bar code");
		setResizable(false);
		setBounds(100, 100, 370, 195);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 250, 240));
		contentPanel.setBorder(null);
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel panel = new JPanel();
			FlowLayout flowLayout = (FlowLayout) panel.getLayout();
			flowLayout.setVgap(15);
			panel.setBackground(new Color(255, 250, 240));
			contentPanel.add(panel, BorderLayout.CENTER);
			{
				JLabel lblEnterBarCode = new JLabel("Enter bar code");
				lblEnterBarCode.setFont(new Font("Tahoma", Font.PLAIN, 17));
				panel.add(lblEnterBarCode);
			}
			{
				textField = new JTextField();
				textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
				textField.setColumns(20);
				panel.add(textField);
			}
		}
		{
			JPanel panel = new JPanel();
			panel.setBackground(new Color(255, 228, 196));
			contentPanel.add(panel, BorderLayout.SOUTH);
			{
				JButton button = new JButton("ok");
				button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {

						findProductByBarCode();
					}
				});
				button.setForeground(Color.WHITE);
				button.setFont(new Font("Tahoma", Font.PLAIN, 17));
				button.setBackground(Color.RED);
				panel.add(button);
			}
		}
	}

	public void findProductByBarCode() {
		factory = new DaoFactory();
		if (!textField.getText().trim().equals("")) {

			ProductDao dao = (ProductDao) factory.getDaoForAbstractClass(Integer.class, Product.class);
			Product product = dao.findProductByBarCode(Integer.parseInt(textField.getText()));
			if (product == null) {
				JOptionPane.showMessageDialog(contentPanel, "There is no product with this bar code", "Error",
						JOptionPane.ERROR_MESSAGE);
			} else {
				openAnotherDialog(product, this.purchase,model);
			}

		} else
			JOptionPane.showMessageDialog(contentPanel, "The field is empty", "Error", JOptionPane.ERROR_MESSAGE);
	}

	public void openAnotherDialog(Product product, Purchase purchase,AbstractTableModel model) {
		EnterAmountOfProducts amount = new EnterAmountOfProducts(product, purchase, model);
		amount.setLocationRelativeTo(null);
		amount.setVisible(true);
		close();
	}
	public void close() {
		WindowEvent winClose = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClose);
	}
	

}
