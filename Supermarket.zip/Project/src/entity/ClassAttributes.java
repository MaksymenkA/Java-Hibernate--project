package entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.PrePersist;
import javax.persistence.Table;

@Entity
@Table(name = "class_attributes")
public class ClassAttributes {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "min_salary", nullable = false)
	private double minSalary;
	
	@Column(name = "min_work_age", nullable = false)
	private int minWorkAge;
	
	@Column(name = "min_discount_percentage", nullable = false)
	private int minDiscountPercentage = 1;
	
	@Column(name = "max_change_of_discount_percentage", nullable = false)
	private  int maxChangeOfDiscountPercentage = 5;

	public ClassAttributes(int minWorkAge, double minSalary,int minDiscountPercentage, int maxChangeOfDiscountPercentage ) {
		this.minWorkAge= minWorkAge;
		this.minSalary = minSalary;
		this.minDiscountPercentage = minDiscountPercentage;
		this.maxChangeOfDiscountPercentage= maxChangeOfDiscountPercentage;
	}

	public ClassAttributes() {
	}

	@PrePersist
	private void saving() {
		setMinSalary(Employee.getMinSalary());
		setMinWorkAge(Employee.getMinWorkAge());
		setMinDiscountPercentage(DiscountCard.getMinDiscountPercentage());
		setMaxChangeOfDiscountPercentage(DiscountCard.getMaxChangeOfDiscountPercentage());
		
	}

	@PostLoad
	private void setAttributes() {
		Employee.setMinSalary(getMinSalary());
		Employee.setMinWorkAge(getMinWorkAge());
		DiscountCard.setMaxChangeOfDiscountPercentage(getMaxChangeOfDiscountPercentage());
		DiscountCard.setMinDiscountPercentage(getMinDiscountPercentage());
		
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	

	public int getMinWorkAge() {
		return minWorkAge;
	}

	public void setMinWorkAge(int minWorkAge) {
		this.minWorkAge = minWorkAge;
	}

	public double getMinSalary() {
		return minSalary;
	}

	public void setMinSalary(double minSalary) {
		this.minSalary = minSalary;
	}

	public int getMinDiscountPercentage() {
		return minDiscountPercentage;
	}

	public void setMinDiscountPercentage(int minDiscountPercentage) {
		this.minDiscountPercentage = minDiscountPercentage;
	}

	public  int getMaxChangeOfDiscountPercentage() {
		return maxChangeOfDiscountPercentage;
	}

	public  void setMaxChangeOfDiscountPercentage(int maxChangeOfDiscountPercentage) {
		this.maxChangeOfDiscountPercentage = maxChangeOfDiscountPercentage;
	}

}
