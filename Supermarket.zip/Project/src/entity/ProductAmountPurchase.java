package entity;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "product_amount_purchase")

public class ProductAmountPurchase {

	// Attribute
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "amount", nullable = false)
	private double amount;

	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST,
			CascadeType.REFRESH }, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_purchase", nullable = false)
	private Purchase purchase;

	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE,
			CascadeType.REFRESH }, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_product", nullable = false)
	private Product product;

	public ProductAmountPurchase(double amount, Purchase purchase, Product product) {
		setAmount(amount);
		setPurchase(purchase);
		setProduct(product);
	}

	public ProductAmountPurchase() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		if (id != null) {
			this.id = id;
		} else
			throw new RuntimeException("Id cannot be null");
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		if (amount > 0.0) {
			this.amount = amount;
		} else
			throw new RuntimeException("Amount cannot be null");
	}

	public Purchase getPurchase() {
		return purchase;
	}

	private void setPurchase(Purchase purchase) {
		if (purchase != null) {
			if (this.purchase != null) {
				this.purchase.removeProductAmount(this);
			}			
			this.purchase = purchase;
			purchase.addProductAmount(this);
		} else
			throw new RuntimeException("Purchase cannot be null");
	}

	public Product getProduct() {
		return product;
	}

	private void setProduct(Product product) {
		if (product != null) {
			if (this.product != null) {
				this.product.removeProductAmount(this);
			}						
			this.product = product;
			product.addProductAmount(this);

		} else
			throw new RuntimeException("Product cannot be null");
	}

	public void removeProductAmount() {
		if (purchase != null) {
			purchase.removeProductAmount(this);
			this.purchase = null;
		}
		if (product != null) {
			product.removeProductAmount(this);
			this.product = null;

		}

	}

}
