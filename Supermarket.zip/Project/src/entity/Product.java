package entity;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "product")
@DiscriminatorColumn(name="production_type",discriminatorType= DiscriminatorType.STRING,length=30)
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)

public abstract class Product {

	// with an attribute
	// composition //multiValue
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "name", nullable = false)
	private String name;
	
	@Column(name = "brand", nullable = false)
	private String brand;
	
	@Column(name = "price", nullable = false)
	private double price;
	
	@Column(name="bar_code", nullable = false)
	private int bar_code;

	@OneToOne(cascade = {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH }, fetch = FetchType.EAGER)
	@JoinColumn(name = "type", nullable=false)
	private ProductLastingType type;
	
	@OneToMany(mappedBy = "product", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<ProductAmountPurchase> productAmounts = new HashSet<>();
	
	@OneToMany(mappedBy = "product", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<ProductAmountOrder> productAmountsOrder = new HashSet<>();
	
	@OneToMany(mappedBy = "product", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<Certificate> certificates = new TreeSet<>();
	
	
	

	public Product(String name, String brand, double price,int bar_code ,ProductLastingType type) {
		setName(name);
		setBrand(brand);
		setPrice(price);
		setBar_code(bar_code);

	}

	public Product() {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		if (name != null) {
			this.name = name;
		} else
			throw new RuntimeException("Name cannot be null");
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		if (brand != null) {
			this.brand = brand;
		} else
			throw new RuntimeException("Brand cannot be null");
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		if (price > 0.0) {
			this.price = price;
		} else
			throw new RuntimeException("Price cannot be lower or equal than 0");
	}
	
	public int getBar_code() {
		return bar_code;
	}

	public void setBar_code(int bar_code) {
		if(bar_code > 0) {
		this.bar_code = bar_code;
		}else
			throw new RuntimeException("Bar code cannot be null");
	}
	

	// with an attribute

	

	public Set<ProductAmountPurchase> getProductAmounts() {
		return productAmounts;
	}

	public ProductLastingType getType() {
		return type;
	}

	public void setType(ProductLastingType type) {
		if(type != null) {
		this.type = type;
		}else 
			throw new RuntimeException("Type cannot be null");
		
	}

	public Set<ProductAmountPurchase> getProductAmount() {
		return new HashSet<>(productAmounts);
	}

	public void setProductAmounts(Set<ProductAmountPurchase> productAmounts) {
		this.productAmounts = productAmounts;
	}

	public void addProductAmount(ProductAmountPurchase productAmount) {

		if (!this.productAmounts.contains(productAmount)) {
			if (productAmount == null) {
				throw new RuntimeException("Product amount cannot be null");
			}
			if (productAmount.getProduct() == this) {
				this.productAmounts.add(productAmount);
				

			} else
				throw new RuntimeException("Product amount is not in this list");
		}
	}

	public void removeProductAmount(ProductAmountPurchase productAmount) {
		if (this.productAmounts.contains(productAmount)) {
			this.productAmounts.remove(productAmount);
			productAmount.removeProductAmount();
		}
	}

	public void removeProductAmount(ProductAmountOrder productAmount) {
		if (this.productAmountsOrder.contains(productAmount)) {
			this.productAmountsOrder.remove(productAmount);
			productAmount.removeProductAmount();
		}
	}
	public void addProductAmount(ProductAmountOrder productAmount) {

		if (!this.productAmountsOrder.contains(productAmount)) {
			if (productAmount == null) {
				throw new RuntimeException("Product amount cannot be null");
			}
			if (productAmount.getProduct() == this) {
				this.productAmountsOrder.add(productAmount);
				

			} else
				throw new RuntimeException("Product amount is not in this list");
		}
	
	}
	public Set<ProductAmountOrder> getProductAmountsOrder() {
		return new HashSet<>(productAmountsOrder);
	}

	public void setProductAmountsOrder(Set<ProductAmountOrder> productAmountsOrder) {
		this.productAmountsOrder = productAmountsOrder;
	}

	// composition


	public void setProductLastingType(ProductLastingType type) {
		if (type != null) {
			if (this.type != null) {
				this.type.removeProduct(this);
			}			
			this.type = type;
			this.type.setProduct(this);
		} else
			throw new RuntimeException("Product cannot be null");
	}
	
	public void removeProductLastingType(ProductLastingType type) {
		type.removeProduct(this);
		this.type = null;
	}


	public void addCertificate(Certificate certificate) {
		if (certificate != null) {
			if (!this.certificates.contains(certificate)) {
				if (certificate.getProduct() != this) {
					throw new RuntimeException("There is such certificate already");
				}
				certificates.add(certificate);
			}
		} else
			throw new RuntimeException("Certificate cannot be null");

	}

	public Set<Certificate> getCertificates() {
		return new TreeSet<>(certificates);
	}

	public void setCertificates(Set<Certificate> certificates) {
		this.certificates = new TreeSet<>(certificates) ;
	}

	public void removeCertificate(Certificate certificate) {
		if (certificates.contains(certificate)) {
			certificates.remove(certificate);
			certificate.removeProduct();
		}
	}

	public String description() {
		// TODO Auto-generated method stub
		return null;
	}

}
