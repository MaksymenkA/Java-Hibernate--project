package entity;



import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

///REWRITE THIS CLASS IS WRONG IMPLEMENTED


enum Status{ACTIVATED, BLOCKED, NON_ACTIVATED}
@Entity
public class Client  {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "name")
	private String name;
	
	@Column(name = "surname")
	private String surname;
	
	@Column(name = "phone_number")
	private String phone_number;
	
	@Column(name = "status")
	@Enumerated( EnumType.STRING)
	private Status status;

	@OneToMany(mappedBy = "client", cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST,
			CascadeType.REFRESH }, fetch = FetchType.LAZY)
	private Set<Purchase> purchases = new HashSet<>();

	@OneToOne(cascade= CascadeType.ALL,
			fetch=FetchType.EAGER)
	@JoinColumn(name="saving_card")
	private SavingCard savingCard;
	
	@OneToOne(cascade=CascadeType.ALL,
			fetch=FetchType.EAGER)
	@JoinColumn(name="discount_card")
	private DiscountCard discountCard;


	public Client(String name, String surname, String phone_number,CardType cardtype, String type,LocalDate expireDate,String brand, String cardName,int discountPercentage,double amountOfMoney) {
		
		setName(name);
		setSurname(surname);
		setPhone_number(phone_number);
		setStatus(Status.ACTIVATED);
		
		if(cardtype.equals(CardType.DISCOUNTCARD)) {
			this.discountCard = new DiscountCard( type, expireDate,brand,cardName,  discountPercentage);
			this.discountCard.setClient(this);
		}else if(cardtype.equals(CardType.SAVINGCARD)) {
			this.savingCard = new SavingCard(type, expireDate,brand,cardName, amountOfMoney);
			this.savingCard.setClient(this);
		}else
			throw new RuntimeException("There is no such type");
	}
	
	public Client(String name, String surname, String phone_number) {
		setName(name);
		setSurname(surname);
		setPhone_number(phone_number);

	}
	
	public Client() {
	}

	


	public void setPurchases(Set<Purchase> purchases) {
		this.purchases = purchases;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setSavingCard(SavingCard savingCard) {
		this.savingCard = savingCard;
	}
	public void setDiscountCard(DiscountCard discountCard) {
		this.discountCard = discountCard;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		if (name != null) {
			this.name = name;
		} else
				throw new RuntimeException("Name cannot be null");
			
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		if (surname != null) {
			this.surname = surname;
		} else
				throw new RuntimeException("surname cannot be null");
			
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		if (phone_number != null) {
			this.phone_number = phone_number;
		} else
				throw new RuntimeException("Phone number cannot be null");
			
	}


	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public SavingCard getSavingCard() {
		return savingCard;
	}

	public DiscountCard getDiscountCard() {
		return discountCard;
	}
	
	public void payPurchase(double money) {
		
	}

	
	
	 public void addCard(DiscountCard discountCard) {
	        if (discountCard == null) {
	            throw new IllegalArgumentException("Card cannot be null");
	        }
	        if (this.discountCard == discountCard) {
	            return;
	        }
	        if (this.savingCard != null) {
	           savingCard.removeClient(this);
	        }
	        this.discountCard = discountCard;
	        discountCard.setClient(this);

	    }

	    public void addCard(SavingCard savingCard) {
	        if (savingCard == null) {
	            throw new IllegalArgumentException("Card cannot be null");
	        }
	        if (this.savingCard == savingCard) {
	            return;
	        } 
	        if (this.discountCard != null) {
	            discountCard.removeClient(this);
	        }
	        this.savingCard = savingCard;
	        savingCard.setClient(this);
	    }

	    public void removeCard() {
	        if (this.savingCard != null) {
	            this.savingCard.removeClient(this);
	            this.savingCard = null;
	        } else if (this.discountCard != null) {
	            this.discountCard.removeClient(this);
	            this.discountCard = null;
	        }
	    }
	
	
	
	    public void addPurchase(Purchase purchase) {
				if (purchase == null) {
					throw new RuntimeException("Purchase cannot be null");
				} else if (!purchases.contains(purchase)) {
					purchases.add(purchase);
					purchase.setClient(this);
				}
			
		}

		public void removePurchase(Purchase purchase) {
				if (purchase == null) {
					throw new RuntimeException("Purchase is not in the list");
				} else if (purchases.size() <= 0) {
					throw new RuntimeException("There is no purchase added");
				} else if (purchases.contains(purchase)) {
					purchases.remove(purchase);
					purchase.removeCashier();
				} else
					throw new RuntimeException("There is no such purchase");
		

		}


	public Set<Purchase> getPurchases() {
			return new HashSet<>(purchases);
		}
	@Override
	public String toString() {
		if (savingCard == null) {
			return "Client [name=" + name + ", surname=" + surname + ", phone_number=" + phone_number
					+ ", discountCard=" + discountCard + "]";

		} else if (discountCard == null) {
			return "Client [name=" + name + ", surname=" + surname + ", phone_number=" + phone_number + ", savingCard="
					+ savingCard + "]";

		} else if(savingCard != null && discountCard!= null ) {
			return "Client [name=" + name + ", surname=" + surname + ", phone_number=" + phone_number + ", savingCard="
					+ savingCard + ", discountCard=" + discountCard + "]";
		}else
			return "Client [name=" + name + ", surname=" + surname + ", phone_number=" + phone_number;

	}

}
