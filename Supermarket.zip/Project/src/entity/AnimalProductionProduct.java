package entity;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("ANIMAL_PRODUCTION")

public class AnimalProductionProduct extends Product{
	
	@Column(name="animal_type")
	private String animal_type;
	
	
	public AnimalProductionProduct( String name, String brand, String animal_type, double price,int bar_code, ProductLastingType type) {
		super( name, brand ,price,bar_code, type);
		setAnimal_type(animal_type);
		
	}
	public AnimalProductionProduct() {
	}

	@Override
	public String description() {
		return "This product is of animal production" +getType();
	}

	@Override
	public String toString() {
		return super.toString();
	}
	public String getAnimal_type() {
		return animal_type;
	}
	public void setAnimal_type(String animal_type) {
		if(animal_type !=null) {
		this.animal_type = animal_type;
		}else
			throw new RuntimeException("Animal type cannot be null");
	}
	

}
