package entity;

import java.time.LocalDate;

import javax.persistence.Entity;

public interface Perishable {
	public void quickSpoile() ;


}
