package entity;


import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToOne;


@Entity
@DiscriminatorColumn(name="card_type",discriminatorType= DiscriminatorType.STRING,length=25)
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)

public abstract class Card {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")	
	private long id;
	
	@Column(name ="type",nullable=false )
	private String type;	
	
	@Column(name ="expire_date",nullable=false )
	private LocalDate expireDate;
	
	@Column(name ="brand",nullable=false )
	private String brand;
	
	@Column(name ="name",nullable=false )
	private String name;
	
	@OneToOne(mappedBy = "savingCard",cascade= {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH },
			fetch=FetchType.EAGER)
	private Client client;
	
	
	public Card( String type, LocalDate expireDate, String brand, String name) {
		setType(type);
		setExpireDate(expireDate);
		setBrand(brand);
		setName(name);
	}
	public Card() {
	}
	
	public abstract String getMainFunction();

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		if(type != null) {
		this.type = type;
		}
	}

	public LocalDate getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(LocalDate expireDate) {
		if(expireDate !=null) {
		this.expireDate = expireDate;
		}
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		if(brand!= null) {
		this.brand = brand;
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		if(name != null) {
		this.name = name;
		}
	}
	

	@Override
	public String toString() {
		return "Card [id=" + id + ", type=" + type + ", expireDate=" + expireDate + ", brand=" + brand + ", name="
				+ name + "]";
	}
	
	
	

}
