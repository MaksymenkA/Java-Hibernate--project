package entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Supplier {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "company_name", nullable = false)
	private String company_name;

	@Column(name = "address", nullable = false)
	private Address address;
	
	@Column(name = "phone_number", nullable = false)
	private String phone_number;
	
	@OneToMany(mappedBy = "supplier", cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST,
			CascadeType.REFRESH }, fetch = FetchType.LAZY)
	private Set<Supplier_Order> orders = new HashSet<>();
	
	public Supplier(String company_name, Address address, String phone_number) {
		
		}
	public Supplier() {
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCompany_name() {
		if(company_name != null) {
		return company_name;
		}else
			throw new RuntimeException("Company name cannot be null");
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		if(address != null) {
		this.address = address;
		}else
			throw new RuntimeException("Address cannot be null");
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		if(phone_number != null) {
		this.phone_number = phone_number;
		}else
			throw new RuntimeException("Phone number cannot be null");
		
	}
	public Set<Supplier_Order> getOrders() {
		return new HashSet<>(orders);
	}
	public void setOrders(Set<Supplier_Order> orders) {
		this.orders = orders;
	}
	
	
	public void addOrder(Supplier_Order order) {
			if (order == null) {
				throw new RuntimeException("Purchase cannot be null");
			} else if (!orders.contains(order)) {
				orders.add(order);
				order.setSupplier(this);
			}
		
	}

	public void removeOrder(Supplier_Order order) {
			if (order == null) {
				throw new RuntimeException("Purchase is not in the list");
			} else if (orders.size() <= 0) {
				throw new RuntimeException("There is no purchase added");
			} else if (orders.contains(order)) {
				orders.remove(order);
				order.removeSupplier();
			} else
				throw new RuntimeException("There is no such purchase");
		

	}
	
	
	
}
