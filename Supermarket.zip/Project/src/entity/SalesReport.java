package entity;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="sales_report")
public class SalesReport {
	//Qualifier

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")	
	private Long id;
	
	@Column(name ="start_date", nullable=false)
	private LocalDate startDate;
	
	@Column(name ="end_date", nullable=false)
	private LocalDate endDate;
	
	
	@OneToMany(mappedBy="salesReport",cascade= { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST,
			CascadeType.REFRESH },fetch=FetchType.LAZY)		
	@MapKey
	private Map<Long, Purchase> purchases = new HashMap<>();

	// Qualifier
	public SalesReport(LocalDate startDate, LocalDate endDate) {
		
		setStartDate(startDate);
		setEndDate(endDate);

	}
	public SalesReport() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		if (id != null) {
			this.id = id;
		} else
			throw new RuntimeException("Id cannot be null");
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		if (startDate != null) {
			this.startDate = startDate;
		} else
			throw new RuntimeException("Start date cannot be null");

	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		if (endDate != null) {
			this.endDate = endDate;
		} else
			throw new RuntimeException("End date cannot be null");
	}
	public void getTotalSum() {
		
	}

	// Qualifier

	public Map<Long, Purchase> getPurchases() {
		return new HashMap<>(purchases);
	}
	public void setPurchases(Map<Long, Purchase> purchases) {
		this.purchases = purchases;
	}
	
	public Purchase getPurchase(Long id) {
		if (id != null) {
			return purchases.get(id);
		} else
			throw new RuntimeException("Id cannot be null");
	}

	public void addPurchase(Purchase newPurchase) {
		if (newPurchase == null) {
			throw new RuntimeException("Purchase cannot be null");
		} else {
			if (!purchases.containsKey(newPurchase.getId())) {
				purchases.put(newPurchase.getId(), newPurchase);
				newPurchase.setSalesReport(this);
			} 
		}
	}

	public void removePurchase(Purchase purchase) {
		if (purchase != null) {
			if (purchases.containsValue(purchase)) {
				purchases.remove(purchase.getId());
				purchase.removeSalesReport();
				
			} 
		} else
			throw new RuntimeException("Id cannot be null");
	}

}
