package entity;

public enum EmployeePosition {
	CASHIER, MANAGER, WAREHOUSEWORKER
}
