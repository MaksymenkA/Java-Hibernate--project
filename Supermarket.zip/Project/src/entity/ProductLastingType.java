package entity;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "product_lasting_type")
public  class ProductLastingType  implements Perishable,LongLasting{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "production_date", nullable = false)
	private LocalDate productionDate;
	
	@Column(name = "expiration_date", nullable = false)
	private LocalDate expirationDate;
	
	@OneToOne(mappedBy = "type",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private Product product;

	public ProductLastingType(LocalDate productionDate, LocalDate expirationDate) {
		setProductionDate(productionDate);
		setExpirationDate(expirationDate);
	}

	public ProductLastingType() {
	}
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	


	public LocalDate getProductionDate() {
		return productionDate;
	}

	public void setProductionDate(LocalDate productionDate) {
		if (productionDate != null) {
			this.productionDate = productionDate;
		} else
			throw new RuntimeException("Production date cannot be null");

	}

	public LocalDate getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(LocalDate expirationDate) {
		if (expirationDate != null) {
			this.expirationDate = expirationDate;
		} else
			throw new RuntimeException("Expiration date cannot be null");
	}
	
	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		if (product != null) {
			if (this.product != null) {
				this.product.removeProductLastingType(this);
			}			
			this.product = product;
			this.product.setProductLastingType(this);
		} else
			throw new RuntimeException("Product cannot be null");
	}
	
	public void removeProduct(Product product) {
		product.removeProductLastingType(this);
		this.product = null;
	}

	@Override
	public String toString() {
		return "productionDate=" + productionDate + ", expirationDate=" + expirationDate;
	}

	@Override
	public void longSpoile() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void quickSpoile() {
		// TODO Auto-generated method stub
		
	}

}
