package entity;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "purchase")
public class Purchase {

	// BASIC
	// With an attribute
	// Qualifier
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "production_date", nullable = false)
	private LocalDate date;

	@OneToMany(mappedBy = "purchase", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<ProductAmountPurchase> productAmounts = new HashSet<>();

	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE,
			CascadeType.REFRESH }, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_cashier", nullable = false)
	private Employee cashier;

	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST,
			CascadeType.REFRESH }, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_sales_report")
	private SalesReport salesReport;

	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE,
			CascadeType.REFRESH }, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_client", nullable = false)
	private Client client;

	public Purchase(LocalDate date, Employee cashier) {
		setDate(date);
		setClient(new Client());
		setCashier(cashier);
	}

	public Purchase() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		if (id != null) {
			this.id = id;
		} else
			throw new RuntimeException("Id cannot be null");
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		if (date != null) {
			this.date = date;
		}
	}

	public double getTotalSum() {
		return 0;
	}

	// BASIC

	public Employee getCashier() {
		return cashier;
	}

	public Set<ProductAmountPurchase> getProductAmounts() {
		return new HashSet<>(productAmounts);
	}

	public void setCashier(Employee cashier) {
		if (this.cashier != cashier) {
			if (cashier != null) {
				if (this.cashier != null) {
					this.cashier.removePurchase(this);
				}
				this.cashier = cashier;
				this.cashier.addPurchase(this);
			} else {
				throw new RuntimeException("Cashier cannot be null");
			}
		}

	}

	public void removeCashier() {
		if (cashier != null) {
			this.cashier.removePurchase(this);
			this.cashier = null;
		}

	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		if (this.client != client) {
			if (client != null) {
				if (this.client != null) {
					if (this.client.getPurchases().isEmpty()) {
						this.client.removePurchase(this);
					}
				}
				this.client = client;
				this.client.addPurchase(this);
			} else {
				throw new RuntimeException("Cashier cannot be null");
			}
		}
	}

	// ATTRIBUTE

	public void setProductAmounts(Set<ProductAmountPurchase> productAmounts) {
		this.productAmounts = productAmounts;
	}

	public void addProductAmount(ProductAmountPurchase productAmount) {

		if (!this.productAmounts.contains(productAmount)) {
			if (productAmount == null) {
				throw new RuntimeException("Product amount cannot be null");
			}
			if (productAmount.getPurchase() == this) {
				this.productAmounts.add(productAmount);
			} else
				throw new RuntimeException("Amount of this purchase is different");
		}

	}

	public void removeProductAmount(ProductAmountPurchase productAmount) {
		if (this.productAmounts.contains(productAmount)) {
			this.productAmounts.remove(productAmount);
			productAmount.removeProductAmount();
		}
	}

	// QUALIFIER

	public SalesReport getSalesReport() {
		return salesReport;
	}

	public void setSalesReport(SalesReport salesReport) {
		if (this.salesReport != salesReport) {
			if (salesReport != null) {
				if (this.salesReport != null) {
					this.salesReport.removePurchase(this);
				}
				this.salesReport = salesReport;
				this.salesReport.addPurchase(this);
			} else
				throw new RuntimeException("Sales report cannot be null");
		}
	}

	public void removeSalesReport() {
		if (salesReport != null) {
			this.salesReport.removePurchase(this);
			this.salesReport = null;
		}

	}

}
