package entity;

import java.time.LocalDate;

import dao.DaoFactory;

public class Main {

	public static void main(String[] args) {
		DaoFactory factory = new DaoFactory();
		//factory.getEntityManager();
		
		

	}
}
