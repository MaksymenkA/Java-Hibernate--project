package entity;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="certificate")
public class Certificate implements Comparable<Certificate>{

	// Composition //Complex attribute 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name ="name", nullable=false)
	private String name;
	
	@Column(name = "brand",nullable=false)
	private String brand;
	
	@ManyToOne(cascade= {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH },
				fetch=FetchType.EAGER)
	@JoinColumn(name="id_product",nullable=false)
	private Product product;
	
	@Column(name ="production_date", nullable=false)
	private LocalDate productionDate;

	public Certificate( String name, String brand, LocalDate productionDate, Product product) {
		
		setName(name);
		setBrand(brand);
		setProductionDate(productionDate);
		setProduct(product);
	}
	public Certificate() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		if (name != null) {
			this.name = name;
		} else
			throw new RuntimeException("Name cannot be null");
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		if (brand != null) {
			this.brand = brand;
		} else
			throw new RuntimeException("Brand cannot be null");
	}

	public LocalDate getProductionDate() {
		return productionDate;
	}

	public void setProductionDate(LocalDate productionDate) {
		if (productionDate != null) {
			this.productionDate = productionDate;
		} else
			throw new RuntimeException("Production date cannot be null");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Product getProduct() {
		return product;
	}

	private void setProduct(Product product) {
		if (product != null) {
			if (this.product != null) {
				this.product.removeCertificate(this);
			}			
			this.product = product;
			this.product.addCertificate(this);
		} else
			throw new RuntimeException("Product cannot be null");
	}
	
	public void removeProduct() {
		this.product.removeCertificate(this);
		this.product = null;
	}
	@Override
	public int compareTo(Certificate o) {
		return this.getProductionDate().compareTo(o.getProductionDate()); 
	}
	@Override
	public String toString() {
		return "Certificate [id=" + id + ", name=" + name + ", brand=" + brand 
				+ ", productionDate=" + productionDate + "]";
	}

	
}
