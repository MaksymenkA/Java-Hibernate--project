package entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("PLANT_PRODUCTION")

public class PlantProductionProduct extends Product {
	
	@Column(name="plant_type")
	private String plant_type;

	public PlantProductionProduct( String name, String brand, double price, int bar_code,ProductLastingType type) {
		super( name, brand, price, bar_code,type);
	}
	public PlantProductionProduct() {
	}

	@Override
	public String description() {
		return "This product is of plant production" +getType();
	}

	@Override
	public String toString() {
		return super.toString();
	}
	public String getPlant_type() {
		return plant_type;
	}
	public void setPlant_type(String plant_type) {
		if(plant_type != null) {
		this.plant_type = plant_type;
		}else 
			throw new RuntimeException("Plant type cannot be null");
		
	}
	

}
