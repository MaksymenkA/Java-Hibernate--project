package entity;


import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;


@Entity
@DiscriminatorValue("SAVING_CARD")
public class SavingCard extends Card {

	@Column(name="amount_of_money")
	private double amountOfMoney = 0.0;
	
	@OneToOne(mappedBy = "savingCard",cascade= {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH },
			fetch=FetchType.EAGER)
	private Client client;
	

	public SavingCard(String type, LocalDate expireDate, String brand, String name, double amountOfMoney) {
		super( type, expireDate, brand, name);
		setAmountOfMoney(amountOfMoney);
	}
	public SavingCard() {
	}

	public Client getClient() {
		return client;
	}
	public double getAmountOfMoney() {
		return amountOfMoney;
	}

	public void setAmountOfMoney(double amountOfMoney) {
		if (amountOfMoney >= 0) {
			this.amountOfMoney = amountOfMoney;
		}else
			throw new RuntimeException("Amount of money cannot be smaller than 0");
		
	}

	@Override
	public String getMainFunction() {
		return getFunction();
	}

	public String getFunction() {
		return "Main function of this card is to save money";
	}

	public void setClient(Client client) {
		if (client != null) {
			if (this.client != null) {
				this.client.removeCard();
			}			
			this.client = client;
			this.client.setSavingCard(this);
		} else
			throw new RuntimeException("Product cannot be null");
	}
	
	public void removeClient(Client client) {
		client.removeCard();
		this.client = null;
	}

	//
	// private void addMoney() {
	//
	// }
	// private void spendMoney() {
	//
	// }
	// private void checkCurrentAmountMoney() {
	//
	// }
	//

}
