package entity;

public enum CardType {
	DISCOUNTCARD, SAVINGCARD
}
