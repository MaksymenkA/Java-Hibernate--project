
package entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Embeddable
public class Address {
	
//	@Id
//	@GeneratedValue
//	@Column(name = "id")
//	private int id;
//	
	@Column(name = "city", nullable = false)
	private String city;
	
	@Column(name = "street", nullable = false)
	private String street;
	
	@Column(name = "house_number", nullable = false)
	private String houseNumber;
	
	@Column(name = "flat")
	private int flat;
	
	
	
	public Address(String city, String street, String houseNumber, int flat) {
		setCity(city);
		setStreet(street);
		setHouseNumber(houseNumber);
		setFlat(flat);
	}
	
	
	
	public Address(String city, String street, String houseNumber) {
		setCity(city);
		setStreet(street);
		setHouseNumber(houseNumber);
		
	}
	
	public Address() {
			
	}



//	public int getId() {
//		return id;
//	}
//
//
//
//	public void setId(int id) {
//		this.id = id;
//	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		if(city != null) {
		this.city = city;
		}else 
			throw new RuntimeException("City cannot be null");
		
	}



	public String getStreet() {
		return street;
	}



	public void setStreet(String street) {
		if(street != null) {
		this.street = street;
		}else 
			throw new RuntimeException("Street cannot be null");
	}



	public String getHouseNumber() {
		return houseNumber;
	}



	public void setHouseNumber(String houseNumber) {
		if(houseNumber != null) {
		this.houseNumber = houseNumber;
		}else
			throw new RuntimeException("House number cannot be null");
	}



	public int getFlat() {
		return flat;
	}



	public void setFlat(int flat) {
		if(flat >0) {
		this.flat = flat;
		}else 
			throw new RuntimeException("Flat number cannot be 0 or smaller");
	}
	
	

}
