package entity;

import java.time.LocalDate;

import javax.persistence.Entity;

public interface LongLasting{

	
	public void longSpoile() ;



}
