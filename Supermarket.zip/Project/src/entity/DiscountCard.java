package entity;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Transient;


@Entity
@DiscriminatorValue("DISCOUNT_CARD")
public class DiscountCard extends Card{
	@Column(name="discount_percentage")
	private int discountPercentage;
	
	@Transient
	private static int minDiscountPercentage = 1;
	
	@Transient
	private static int maxChangeOfDiscountPercentage = 5;
	
	@OneToOne(mappedBy = "discountCard",cascade= {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH },
			fetch=FetchType.EAGER)
	private Client client;
	


	public DiscountCard( String type, LocalDate expireDate, String brand, String name, int discountPercentage) {
		super( type, expireDate, brand, name);
		setDiscountPercentage(discountPercentage);
	}
	

	public DiscountCard() {
	}
	

	
	public static int getMinDiscountPercentage() {
		return minDiscountPercentage;
	}


	public static void setMinDiscountPercentage(int minDiscountPercentage) {
		DiscountCard.minDiscountPercentage = minDiscountPercentage;
	}


	public static int getMaxChangeOfDiscountPercentage() {
		return maxChangeOfDiscountPercentage;
	}


	public static void setMaxChangeOfDiscountPercentage(int maxChangeOfDiscountPercentage) {
		DiscountCard.maxChangeOfDiscountPercentage = maxChangeOfDiscountPercentage;
	}


	public Client getClient() {
		return client;
	}


	public int getDiscountPercentage() {
		return discountPercentage;
	}

	public void setDiscountPercentage(int discountPercentage) {
			if(discountPercentage > 0) {		
		this.discountPercentage = discountPercentage;
			}else
				throw new RuntimeException("Discount percantage cannot be smaller than 0");
	}


	public void setClient(Client client) {
		if (client != null) {
			if (this.client != null) {
				this.client.removeCard();
			}			
			this.client = client;
			this.client.setDiscountCard(this);
		} else
			throw new RuntimeException("Product cannot be null");
	}
	
	public void removeClient(Client client) {
		client.removeCard();
		this.client = null;
	}


	@Override
	public String getMainFunction() {
		return getFunction();
	}
	public String getFunction() {
		return "Main function of this card is to discount purchases";
	}
		
	
	public static void discountPurchase() {
		
	}

}
