package entity;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;


@Entity
public class Supplier_Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "date", nullable = false)
	private LocalDate date;

	@OneToMany(mappedBy = "supplier_order", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<ProductAmountOrder> productAmounts = new HashSet<>();
	
	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST,
			CascadeType.REFRESH }, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_supplier",nullable=false)
	private Supplier supplier;
	
	public Supplier_Order( LocalDate date) {
		setDate(date);
		
	}
	public Supplier_Order() {
	}
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		if(date != null) {
		this.date = date;
		}else 
			throw new RuntimeException("Date cannot be null");
	}
	public double getTotalSum() {
		return 0;
	}
	
	
	
	
	public Set<ProductAmountOrder> getProductAmounts() {
		return productAmounts;
	}
	public Supplier getSupplier() {
		return supplier;
	}
	public void setSupplier(Supplier supplier) {
		if (this.supplier != supplier) {
			if (supplier != null) {
				if (this.supplier != null) {
					this.supplier.removeOrder(this);
				}
				this.supplier = supplier;
				this.supplier.addOrder(this);
			} else
				throw new RuntimeException("Sales report cannot be null");
		}
	}
	public void removeSupplier() {
		this.supplier.removeOrder(this);
		this.supplier = null;
	}
	
	
	public void removeProductAmount(ProductAmountOrder productAmount) {
		if (this.productAmounts.contains(productAmount)) {
			this.productAmounts.remove(productAmount);
			productAmount.removeProductAmount();
		}
	}
	public Set<ProductAmountOrder> getProductAmount() {
		return new HashSet<>(productAmounts);
	}

	public void setProductAmounts(Set<ProductAmountOrder> productAmounts) {
		this.productAmounts = productAmounts;
	}
	public void addProductAmount(ProductAmountOrder productAmount) {

		if (!this.productAmounts.contains(productAmount)) {
			if (productAmount == null) {
				throw new RuntimeException("Product amount cannot be null");
			}
			if (productAmount.getOrder() == this) {
				this.productAmounts.add(productAmount);
			} else
				throw new RuntimeException("Amount of this purchase is different");
		}

	}

}
