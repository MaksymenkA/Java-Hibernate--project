package entity;

import java.time.LocalDate;
import java.time.Period;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

@Entity

public class Employee {

	// optional attribute,class attribute
	// BASIC //overlapping//dynamic - Cashier

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "name", nullable = false)
	private String name;

	@Column(name = "surname", nullable = false)
	private String surname;

	@Transient
	private static int minWorkAge = 18;

	@Column(name = "data_of_birth", nullable = false)
	private LocalDate data_of_birth;

	@Column(name = "phone_number", nullable = false)
	private String phoneNumber;

	@Column(name = "email")
	private String email;

	@Column(name = "address", nullable = false)
	private Address address;

	@Column(name = "hire_date", nullable = false)
	private LocalDate hireDate;

	@Column(name = "username", nullable = false, unique=true)
	private String username;

	@Column(name = "password", nullable = false)
	private String password;

	@Transient
	private static double minSalary = 2500;

	@Column(name = "salary", nullable = false)
	private double salary;

	@OneToMany(mappedBy = "cashier", cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST,
			CascadeType.REFRESH }, fetch = FetchType.LAZY)
	private Set<Purchase> purchases = new HashSet<>();

	@ElementCollection(targetClass = EmployeePosition.class)
	@JoinTable(name = "employee_positions", joinColumns = @JoinColumn(name = "employee_id"))
	@Column(name = "position", nullable = false)
	@Enumerated(EnumType.STRING)
	private  Set<EmployeePosition> positions = new HashSet<>();
	
	

	public Employee(Set<EmployeePosition> positions, String name, String surname, LocalDate date_of_birth, String email,
			Address address, String phoneNumber, LocalDate hiredate, String username, String password, double salary) {
		setPositions(positions);
		setName(name);
		setSurname(surname);
		setData_of_birth(date_of_birth);
		setPhoneNumber(phoneNumber);
		setEmail(email);
		setAddress(address);
		setHireDate(hiredate);
		setUsername(username);
		setPassword(password);
		setSalary(salary);
	}

	public Employee(Set<EmployeePosition> positions, String name, String surname, LocalDate date_of_birth,
			 String phoneNumber,Address address, LocalDate hiredate, String username, String password, double salary) {
		setPositions(positions);
		setName(name);
		setSurname(surname);
		setData_of_birth(date_of_birth);
		setPhoneNumber(phoneNumber);
		setAddress(address);
		setHireDate(hiredate);
		setUsername(username);
		setPassword(password);
		setSalary(salary);
	}

	public Employee(EmployeePosition position, String name, String surname, LocalDate date_of_birth, String phoneNumber,
			String email, Address address, LocalDate hireDate, String username, String password, double salary) {
		addPosition(position);
		setName(name);
		setSurname(surname);
		setData_of_birth(date_of_birth);
		setPhoneNumber(phoneNumber);
		setEmail(email);
		setAddress(address);
		setHireDate(hireDate);
		setUsername(username);
		setPassword(password);
		setSalary(salary);
	}

	public Employee(EmployeePosition position, String name, String surname, LocalDate date_of_birth, String phoneNumber,
			Address address, LocalDate hireDate, String username, String password, double salary) {
		addPosition(position);
		setName(name);
		setSurname(surname);
		setData_of_birth(date_of_birth);
		setPhoneNumber(phoneNumber);
		setAddress(address);
		setHireDate(hireDate);
		setUsername(username);
		setPassword(password);
		setSalary(salary);
	}

	public Employee() {
	}

	// Basic
	public void showReportOfPurchases() {
		if (positions.contains(EmployeePosition.CASHIER)) {
			System.out.println("Report of purchasses: ");
			for (Purchase p : purchases) {
				System.out.println(p);
			}
		} else
			throw new RuntimeException("Employee is not a cashier");
	}

	public void addPurchase(Purchase purchase) {
		if (positions.contains(EmployeePosition.CASHIER)) {
			if (purchase == null) {
				throw new RuntimeException("Purchase cannot be null");
			} else if (!purchases.contains(purchase)) {
				purchases.add(purchase);
				purchase.setCashier(this);
			}
		} else
			throw new RuntimeException("Employee is not a cashier");

	}

	public void removePurchase(Purchase purchase) {
		if (positions.contains(EmployeePosition.CASHIER)) {
			if (purchase == null) {
				throw new RuntimeException("Purchase is not in the list");
			} else if (purchases.size() <= 0) {
				throw new RuntimeException("There is no purchase added");
			} else if (purchases.contains(purchase)) {
				purchases.remove(purchase);
				purchase.removeCashier();
			} else
				throw new RuntimeException("There is no such purchase");
		} else
			throw new RuntimeException("Employee is not a cashier");

	}

	public Set<Purchase> getPurchases() {
		if (positions.contains(EmployeePosition.CASHIER)) {
			return new HashSet<>(purchases);
		} else
			throw new RuntimeException("Employee is not a cashier");
	}

	public void setPurchases(Set<Purchase> purchases) {
		if (positions.contains(EmployeePosition.CASHIER)) {
			this.purchases = purchases;
		} else
			throw new RuntimeException("Employee is not a cashier");
	}

	private void addPosition(EmployeePosition position) {
		if (position != null) {
			positions.add(position);
		}
	}

	public void removePosition(EmployeePosition position) {
		if (positions.size() > 1) {
			if (positions.contains(position)) {
				positions.remove(position);
			}
		}
	}

	public Set<EmployeePosition> getPositions() {
		return new HashSet<>(positions);
	}

	public void setPositions(Set<EmployeePosition> positions) {
		if (positions != null && !positions.isEmpty()) {
			this.positions = positions;
		} else
			throw new RuntimeException("List cannot be empty and list should contains values");
	}

	/**********************************************
	 * Dynamic
	 **********************************************/
	public void becomeCashier() {
		if (!positions.contains(EmployeePosition.CASHIER)) {
			addPosition(EmployeePosition.CASHIER);
		}
	}

	public void becomeManager() {
		if (!positions.contains(EmployeePosition.MANAGER)) {

			addPosition(EmployeePosition.MANAGER);
		}
	}

	public void becomeWarehouseWorker() {
		if (!positions.contains(EmployeePosition.WAREHOUSEWORKER)) {
			addPosition(EmployeePosition.WAREHOUSEWORKER);
		}
	}

	public void recordDelivery() {
		if (positions.contains(EmployeePosition.WAREHOUSEWORKER)) {
			System.out.println("Recording delivery");
		} else
			throw new RuntimeException("Employee is not a warehouse worker");

	}

	public void serviceClient() {
		if (positions.contains(EmployeePosition.CASHIER)) {
			System.out.println("Scanning products");
		} else
			throw new RuntimeException("Employee is not a cashier");
	}
	public void checkAvailabilityOfCard(int id) {
		if (positions.contains(EmployeePosition.CASHIER)) {
			System.out.println("Search by id if id is of type Discount card then it takes discount properties id it is saving card than it becomes saving card");
		} else
			throw new RuntimeException("Employee is not a cashier");
	}


	public void viewEmployee() {
		if (positions.contains(EmployeePosition.MANAGER)) {
			System.out.println("Checking list of employee");
		} else
			throw new RuntimeException("Employee is not a manager");
	}

	public void checkListOfProducts() {
		if (positions.contains(EmployeePosition.MANAGER)) {
			System.out.println("Checking list of products");
		} else
			throw new RuntimeException("Employee is not a manager");

	}

	public void addSupllier() {
		if (positions.contains(EmployeePosition.MANAGER)) {
			System.out.println("Adding supplier to the list");
		} else
			throw new RuntimeException("Employee is not a manager");

	}

	public void placeOrderForSupplier() {
		if (positions.contains(EmployeePosition.MANAGER)) {
			System.out.println("Make an order and send to the supplier");
		} else
			throw new RuntimeException("Employee is not a manager");

	}

	/**************************************************************************************************************/
	// derrived
	public int getWorkingDays() {
		LocalDate currentDate = LocalDate.now();
		Period workingDays = Period.between(hireDate, currentDate);
		return workingDays.getDays();
	}

	public String getName() {
		return name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		if (name != null) {
			this.name = name;
		} else
			throw new RuntimeException("Name cannot be null");
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		if (surname != null) {
			this.surname = surname;
		} else
			throw new RuntimeException("Surname cannot be null");
	}

	public LocalDate getData_of_birth() {
		return data_of_birth;
	}

	public void setData_of_birth(LocalDate data_of_birth) {
		if (data_of_birth != null) {
			this.data_of_birth = data_of_birth;
		} else
			throw new RuntimeException("Date of birth cannot be null");
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		if (phoneNumber != null) {
			this.phoneNumber = phoneNumber;
		} else
			throw new RuntimeException("Phone number cannot be null");
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		if (email != null) {
			this.email = email;
		} else
			throw new RuntimeException("Email cannot be null");
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public LocalDate getHireDate() {
		return hireDate;
	}

	public void setHireDate(LocalDate hireDate) {
		if (hireDate != null) {
			this.hireDate = hireDate;
		} else
			throw new RuntimeException("Hire date cannot be null");

	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		if (username != null) {
			this.username = username;
		} else
			throw new RuntimeException("Username cannot be null");
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		if (password != null) {
			if (password.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,40}$")) {
				this.password = password;
			} else
				throw new RuntimeException(
						"Contain at least one digit.\r\n" + "Contain at least one lower case character.\r\n"
								+ "Contain at least one upper case character.\r\n"
								+ "Contain at least on special character from [ @ # $ % ! . ]. \r\n"
								+ "Contain no whitespace allowed in the entire string.\r\n"
								+ "Contain at least from 8 to 40 characters \r\n");
		} else
			throw new RuntimeException("Password cannot be null");
	
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		if (salary > Employee.minSalary) {
			this.salary = salary;
		} else
			throw new RuntimeException("Salary cannot be smaller than minimum salary");
	}

	public static double getMinSalary() {
		return minSalary;
	}

	public static void setMinSalary(double minSalary) {
		if (minSalary > 0.0) {
			Employee.minSalary = minSalary;
		} else
			throw new RuntimeException("Salary cannot be smaller 0");
	}

	
	public static int getMinWorkAge() {
		return minWorkAge;
	}

	public static void setMinWorkAge(int minWorkAge) {
		if(minWorkAge >=18) {
		Employee.minWorkAge = minWorkAge;
		}else
			throw new RuntimeException("Work age cannot be smaller than 18");
	}

	@Override
	public String toString() {
		if (email != null) {
			return "Employee [name=" + name + ", surname=" + surname + ", data_of_birth=" + data_of_birth
					+ ", phoneNumber=" + phoneNumber + ",email" + email + ", username=" + username + ", password="
					+ password + ", salary=" + salary + "]";
		} else
			return "Employee [name=" + name + ", surname=" + surname + ", data_of_birth=" + data_of_birth
					+ ", phoneNumber=" + phoneNumber + ", username=" + username + ", password=" + password + ", salary="
					+ salary + "]";
	}

}
