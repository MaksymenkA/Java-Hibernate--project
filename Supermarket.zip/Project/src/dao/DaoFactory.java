package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import entity.Card;
import entity.Client;
import entity.Employee;
import entity.Product;
import entity.ProductAmountPurchase;
import entity.Purchase;

public class DaoFactory {

	private EntityManager entityManager;

	public DaoFactory() {
		entityManager = getEntityManager();
	}

	public EntityManager getEntityManager() {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("my_persistence_unit");
		EntityManager manager = factory.createEntityManager();
		return manager;
	}

	public <K, E> Dao<K, E> getDAO(Class<K> k, Class<E> e) {
		try {
			E entity = e.newInstance();
			if (entity instanceof Employee) {
				EmployeeDao dao = new EmployeeDao(entityManager);
				return (Dao<K, E>) dao;
			} else if (entity instanceof Card) {
				CardDao card_Dao = new CardDao(entityManager);
				return (Dao<K, E>) card_Dao;
			} else if (entity instanceof Client) {
				ClientDao client_dao = new ClientDao(entityManager);
				return (Dao<K, E>) client_dao;
			} else if (entity instanceof Product) {
				ProductDao product_dao = new ProductDao(entityManager);
				return (Dao<K, E>) product_dao;
			} else if (entity instanceof Purchase) {
				PurchaseDao purchase_dao = new PurchaseDao(entityManager);
				return (Dao<K, E>) purchase_dao;
			}else if (entity instanceof ProductAmountPurchase) {
					ProductAmountPurchaseDao amount_dao = new ProductAmountPurchaseDao(entityManager);
					return (Dao<K, E>) amount_dao;
			} else
				throw new RuntimeException("Entity is not written in DaoFactory");

		} catch (InstantiationException ex) {
			ex.printStackTrace();
		} catch (IllegalAccessException ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public <K, E> Dao<K, E> getDaoForAbstractClass(Class<K> k, Class<E> e) {
		try {
			System.out.println(e.getName());
			if (e.getName().equals(Product.class.getName())) {
				ProductDao product_dao = new ProductDao(entityManager);
				System.out.println("our product");
				return (Dao<K, E>) product_dao;
			} else if (e.getName().equals(Card.class.getName())) {
				System.out.println("our card");
				CardDao card_Dao = new CardDao(entityManager);
				return (Dao<K, E>) card_Dao;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
}
