package dao;

import java.util.List;

public interface Dao <K, E extends Object>{
    void create(E entity);
    void delete(E entity);
    void update(E entity);
    E findById(K key);
    List<E> findAll();
}
