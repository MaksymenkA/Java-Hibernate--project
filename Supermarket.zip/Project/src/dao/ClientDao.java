package dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import entity.Card;
import entity.Client;
import entity.Employee;

public class ClientDao implements Dao<Integer, Client> {

	EntityManager manager;

	public ClientDao(EntityManager manager) {
		this.manager = manager;
	}

	@Override
	public void create(Client entity) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.persist(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
	}

	@Override
	public void delete(Client entity) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.remove(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}

	}

	@Override
	public void update(Client entity) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.merge(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
	}

	@Override
	public Client findById(Integer key) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			Client client = manager.find(Client.class, new Integer(key));

			transaction.commit();
			return client;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return null;
	}
	public Client findClientByCard(long cardId) {
		Client client;
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			Query query = manager.createQuery("Select client from Client client where client.savingCard.id= :cardId"
											+ " or client.discountCard.id= :cardId");
			client = (Client) query.setParameter("cardId", cardId).getSingleResult();
			transaction.commit();
			return client;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return null;
		
	}


	@Override
	public List<Client> findAll() {
		List<Client> clients = new ArrayList<>();
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			clients = manager.createQuery("Select client from Client client").getResultList();
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return clients;

	}

}
