package dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import entity.Card;
import entity.Employee;
import entity.Product;

public class ProductDao implements Dao<Integer, Product> {

	EntityManager manager;

	public ProductDao(EntityManager manager) {
		this.manager = manager;
	}

	@Override
	public void create(Product entity) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.persist(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
	}

	@Override
	public void delete(Product entity) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.remove(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
	}

	@Override
	public void update(Product entity) {

		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.merge(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
	}

	@Override
	public Product findById(Integer key) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			Product product = manager.find(Product.class, new Integer(key));

			transaction.commit();
			return product;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return null;
	}

	@Override
	public List<Product> findAll() {
		List<Product> products = new ArrayList<>();
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			products = manager.createQuery("Select product from Product product").getResultList();
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return products;
	}

	public Product findProductByBarCode(int bar_code) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			Query query = manager
					.createQuery("Select product from Product product where product.bar_code= :my_bar_code");
			Product product = (Product) query.setParameter("my_bar_code", bar_code).getSingleResult();
			transaction.commit();
			return product;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return null;
	}

}
