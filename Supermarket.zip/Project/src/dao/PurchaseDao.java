package dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import entity.Card;
import entity.Purchase;

public class PurchaseDao implements Dao<Long, Purchase> {

	EntityManager manager;

	public PurchaseDao(EntityManager manager) {
		this.manager = manager;
	}

	@Override
	public void create(Purchase entity) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.persist(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
	}

	@Override
	public void delete(Purchase entity) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.remove(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
	}

	@Override
	public void update(Purchase entity) {

		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.merge(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
	}

	@Override
	public Purchase findById(Long key) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			Purchase purchase = manager.find(Purchase.class, new Long(key));

			transaction.commit();
			return purchase;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return null;
	}

	@Override
	public List<Purchase> findAll() {
		List<Purchase> purchases = new ArrayList<>();
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			purchases = manager.createQuery("Select purchase from Purchase purchase").getResultList();
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return purchases;
	}

}
