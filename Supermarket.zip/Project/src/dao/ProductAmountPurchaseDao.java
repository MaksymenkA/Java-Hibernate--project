package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import entity.Client;
import entity.ProductAmountPurchase;

public class ProductAmountPurchaseDao implements Dao<Long, ProductAmountPurchase> {

	EntityManager manager;
	
	public ProductAmountPurchaseDao(EntityManager manager) {
		this.manager = manager;
	}
	@Override
	public void create(ProductAmountPurchase entity) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.persist(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}		
	}

	@Override
	public void delete(ProductAmountPurchase entity) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.remove(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}		
	}

	@Override
	public void update(ProductAmountPurchase entity) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.merge(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}		
	}

	@Override
	public ProductAmountPurchase findById(Long key) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			ProductAmountPurchase amount = manager.find(ProductAmountPurchase.class, new Long(key));

			transaction.commit();
			return amount;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return null;
	}

	@Override
	public List<ProductAmountPurchase> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
