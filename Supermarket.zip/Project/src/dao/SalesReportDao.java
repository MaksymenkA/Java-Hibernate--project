package dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import entity.Card;
import entity.SalesReport;

public class SalesReportDao implements Dao<Long, SalesReport> {

	EntityManager manager;

	public SalesReportDao(EntityManager manager) {
		this.manager = manager;

	}

	@Override
	public void create(SalesReport entity) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.persist(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
	}

	@Override
	public void delete(SalesReport entity) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.remove(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
	}

	@Override
	public void update(SalesReport entity) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			manager.merge(entity);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
	}

	@Override
	public SalesReport findById(Long key) {
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			SalesReport report = manager.find(SalesReport.class, new Long(key));

			transaction.commit();
			return report;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return null;
	}

	@Override
	public List<SalesReport> findAll() {
		List<SalesReport> reports = new ArrayList<>();
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			reports = manager.createQuery("Select report from SalesReport report").getResultList();
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return reports;
	}
}
